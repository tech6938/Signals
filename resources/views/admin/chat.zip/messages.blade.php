@forelse($messages as $message)
  @if($message->sender_id == auth()->id())
    <div class="chat-message admin">
      <div class="chat-bubble admin">
        <strong>You (Admin)</strong><br>
        {{ $message->message }}
        <div class="chat-time">{{ $message->created_at->diffForHumans() }}</div>
      </div>
    </div>
  @else
    <div class="chat-message user">
      <div class="chat-bubble user">
        <strong>{{ $message->sender->f_name }}</strong><br>
        {{ $message->message }}
        <div class="chat-time">{{ $message->created_at->diffForHumans() }}</div>
      </div>
    </div>
  @endif
@empty
  <p class="text-center">{{ __('messages.no_messages_yet') }}</p>
@endforelse

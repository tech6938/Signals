@extends('admin.includes.layout')


@section('content')
<style>
  .chat-box { height: 400px; overflow-y: auto; background: #f9f9f9; padding: 15px; }
  .chat-message { display: flex; margin-bottom: 15px; align-items: flex-end; }
  .chat-message.admin { justify-content: flex-start; }
  .chat-message.user { justify-content: flex-end; }
  .chat-bubble { max-width: 70%; padding: 10px; border-radius: 10px; font-size: 14px; }
  .chat-bubble.admin { background: #d1f7c4; text-align: left; }
  .chat-bubble.user { background: #e4e6eb; text-align: right; }
  .chat-time { font-size: 11px; color: #666; margin-top: 5px; }
</style>

<div class="content-wrapper">
  <section class="content-header">
    <div class="header-icon"><i class="fa fa-comments"></i></div>
    <div class="header-title">
      <h1>{{ __('messages.chat_with') }} {{ $user->f_name }}</h1>
      <small>{{ __('messages.conversation_history') }}</small>
    </div>
  </section>

  <section class="content">
    <div class="row">
      <div class="col-sm-12">
        <div class="panel panel-bd lobidrag">
          <div class="panel-heading">
            <h4 class="panel-title">{{ __('messages.conversation') }}</h4>
          </div>

          {{-- Chat messages --}}
          <div id="chat-box" class="panel-body chat-box">
            @include('admin.chat.messages')
          </div>

          {{-- Reply form --}}
          <div class="panel-footer">
            <form id="chatForm" method="POST" action="{{ route('admin.chat.reply', $user->id) }}">
              @csrf
              <div class="input-group">
                <input type="text" name="message" id="messageInput" class="form-control" placeholder="Type your reply..." required>
                <span class="input-group-btn">
                  <button class="btn btn-success" type="submit">{{ __('messages.send') }}</button>
                </span>
              </div>
            </form>
          </div>

        </div>
      </div>
    </div>
  </section>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
document.addEventListener("DOMContentLoaded", function() {
  var chatBox = document.getElementById("chat-box");
  chatBox.scrollTop = chatBox.scrollHeight;

  // Send message via AJAX
  $('#chatForm').on('submit', function(e) {
    e.preventDefault();

    let form = $(this);
    let url = form.attr('action');

    $.ajax({
      url: url,
      type: "POST",
      data: form.serialize(),
      success: function() {
        $('#messageInput').val('');
        refreshMessages();
      },
      error: function(xhr) {
        alert("Error: " + (xhr.responseJSON?.message ?? "Failed to send message"));
      }
    });
  });

  // Reload only messages
  function refreshMessages() {
    $.get("{{ route('admin.chat.show', $user->id) }}?ajax=1", function(data) {
      $('#chat-box').html(data);
      chatBox.scrollTop = chatBox.scrollHeight;
    });
  }

  // Auto-refresh every 5s
  setInterval(refreshMessages, 5000);
});
</script>
@endsection

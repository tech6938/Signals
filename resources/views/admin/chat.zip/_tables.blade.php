<div id="chat-tables">
    <!-- Subscribers Table -->
    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-bd lobidrag">
                <div class="panel-heading">
                    <h4 class="panel-title">Subscribers Messages</h4>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Sender</th>
                                    <th>Message</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th class="no-print">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($subscriberMessages as $message)
                                <tr @if(!$message->is_read) style="background:#f9f9f9" @endif>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $message->sender->f_name ?? 'Unknown User' }}</td>
                                    <td>{{ Str::limit($message->message, 50) }}</td>
                                    <td>
                                        @if($message->is_read)
                                        <span class="badge badge-success">Read</span>
                                        @else
                                        <span class="badge badge-warning">Unread</span>
                                        @endif
                                    </td>
                                    <td>{{ $message->created_at->format('d M Y h:i A') }}</td>
                                    <td>
                                        <a href="{{ route('admin.chat.show', $message->sender_id) }}" class="btn btn-primary btn-sm">
                                            <i class="fa fa-eye"></i> Open
                                        </a>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="6" class="text-center">No subscriber messages found.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>

                        @if($subscriberMessages->hasPages())
                        <div class="d-flex justify-content-end">
                            {{ $subscriberMessages->links() }}
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Simple Users Table -->
    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-bd lobidrag">
                <div class="panel-heading">
                    <h4 class="panel-title">Simple Users Messages</h4>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Sender</th>
                                    <th>Message</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                    <th class="no-print">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @forelse($simpleUserMessages as $message)
                                <tr @if(!$message->is_read) style="background:#f9f9f9" @endif>
                                    <td>{{ $loop->iteration }}</td>
                                    <td>{{ $message->sender->f_name ?? 'Unknown User' }}</td>
                                    <td>{{ Str::limit($message->message, 50) }}</td>
                                    <td>
                                        @if($message->is_read)
                                        <span class="badge badge-success">Read</span>
                                        @else
                                        <span class="badge badge-warning">Unread</span>
                                        @endif
                                    </td>
                                    <td>{{ $message->created_at->format('d M Y h:i A') }}</td>
                                    <td>
                                        <a href="{{ route('admin.chat.show', $message->sender_id) }}" class="btn btn-primary btn-sm">
                                            <i class="fa fa-eye"></i> Open
                                        </a>
                                    </td>
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="6" class="text-center">No simple user messages found.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>

                        @if($simpleUserMessages->hasPages())
                        <div class="d-flex justify-content-end">
                            {{ $simpleUserMessages->links() }}
                        </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
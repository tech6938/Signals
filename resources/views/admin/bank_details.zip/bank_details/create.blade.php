@extends('admin.includes.layout')

@section('content')

<div class="content-wrapper">
    <!-- Content Header -->
    <section class="content-header">
        <div class="header-icon">
            <i class="fa fa-university"></i>
        </div>
        <div class="header-title">
            <h1>{{ __('Bank Details') }}</h1>
            <small>Add / Manage Bank Account Information</small>
            <ol class="breadcrumb hidden-xs">
                <li><a href="{{ route('dashboard') }}"><i class="pe-7s-home"></i> Home</a></li>
                <li class="active">Bank Details</li>
            </ol>
        </div>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-sm-12">
                <div class="panel panel-bd lobidrag">
                    <div class="panel-heading">
                        <div class="btn-group">
                            <a class="btn btn-success" href="{{ route('bankDetails.index') }}">
                                <i class="fa fa-table"></i> Bank Details Table
                            </a>
                        </div>
                    </div>

                    <div class="panel-body">
                        {{-- Show Validation Errors --}}
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif

                        {{-- Create Bank Detail Form --}}
                        <form action="{{ route('bankDetails.store') }}" method="POST">
                            @csrf
                            <div class="row">
                                <!-- Bank Name -->
                                <div class="form-group col-md-6">
                                    <label for="bank_name">Bank Name</label>
                                    <input type="text" name="bank_name" id="bank_name" class="form-control"
                                        placeholder="Enter Bank Name" value="{{ old('bank_name') }}" required>
                                    <div class="text-danger">{{ $errors->first('bank_name') }}</div>
                                </div>

                                <!-- Account Title -->
                                <div class="form-group col-md-6">
                                    <label for="account_title">Account Title</label>
                                    <input type="text" name="account_title" id="account_title" class="form-control"
                                        placeholder="Enter Account Title" value="{{ old('account_title') }}" required>
                                    <div class="text-danger">{{ $errors->first('account_title') }}</div>
                                </div>

                                <!-- IBAN -->
                                <div class="form-group col-md-6">
                                    <label for="iban">IBAN</label>
                                    <input type="text" name="iban" id="iban" class="form-control"
                                        placeholder="Enter IBAN" value="{{ old('iban') }}" required>
                                    <div class="text-danger">{{ $errors->first('iban') }}</div>
                                </div>

                                <!-- Swift Code -->
                                <div class="form-group col-md-6">
                                    <label for="swift_code">Swift Code</label>
                                    <input type="text" name="swift_code" id="swift_code" class="form-control"
                                        placeholder="Enter Swift Code" value="{{ old('swift_code') }}">
                                    <div class="text-danger">{{ $errors->first('swift_code') }}</div>
                                </div>

                                <!-- Status -->
                                <div class="form-group col-md-6">
                                    <label for="is_active">Status</label>
                                    <select name="is_active" id="is_active" class="form-control" required>
                                        <option value="1" {{ old('is_active') == '1' ? 'selected' : '' }}>Active</option>
                                        <option value="0" {{ old('is_active') == '0' ? 'selected' : '' }}>Inactive</option>
                                    </select>
                                    <div class="text-danger">{{ $errors->first('is_active') }}</div>
                                </div>
                            </div>

                            <div class="col-sm-12 reset-button">
                                <button type="reset" class="btn btn-warning">Reset</button>
                                <button type="submit" class="btn btn-success">Save Bank Details</button>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

@endsection

@extends('admin.includes.layout')

@section('content')
<div class="content-wrapper">
  <!-- Content Header -->
  <section class="content-header">
    <div class="header-icon">
      <i class="fa fa-university"></i>
    </div>
    <div class="header-title">
      <h1>Edit Bank Details</h1>
      <small>Update bank account information</small>
      <ol class="breadcrumb hidden-xs">
        <li><a href="{{ route('dashboard') }}"><i class="pe-7s-home"></i> Home</a></li>
        <li class="active">Edit Bank</li>
      </ol>
    </div>
  </section>

  <!-- Main content -->
  <section class="content">
    <div class="row">
      <div class="col-sm-12">
        <div class="panel panel-bd lobidrag">
          <div class="panel-heading">
            <div class="btn-group">
              <a class="btn btn-success" href="{{ route('bankDetails.index') }}">
                <i class="fa fa-table"></i> All Banks
              </a>
            </div>
          </div>

          <div class="panel-body">
            @if ($errors->any())
              <div class="alert alert-danger">
                <ul class="mb-0">
                  @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                  @endforeach
                </ul>
              </div>
            @endif

            <form action="{{ route('bankDetails.update', $bank->id) }}" method="POST">
              @csrf
              @method('PUT')

              <div class="row">
                <!-- User -->
               

                <!-- Bank Name -->
                <div class="form-group col-md-6">
                  <label>Bank Name</label>
                  <input type="text" name="bank_name" class="form-control" value="{{ $bank->bank_name }}" required>
                </div>

                <!-- Account Title -->
                <div class="form-group col-md-6">
                  <label>Account Title</label>
                  <input type="text" name="account_title" class="form-control" value="{{ $bank->account_title }}" required>
                </div>

                <!-- Account Number -->
               

                <!-- IBAN -->
                <div class="form-group col-md-6">
                  <label>IBAN</label>
                  <input type="text" name="iban" class="form-control" value="{{ $bank->iban }}">
                </div>

                <!-- Branch Code -->
                <div class="form-group col-md-6">
                  <label>Branch Code</label>
                  <input type="text" name="branch_code" class="form-control" value="{{ $bank->branch_code }}">
                </div>

                <!-- Description -->
                <div class="form-group col-md-12">
                  <label>Description</label>
                  <textarea name="description" class="form-control" rows="4" placeholder="Enter additional bank details...">{{ $bank->description }}</textarea>
                </div>
              </div>

              <div class="col-sm-12 reset-button">
                <button type="reset" class="btn btn-warning">Reset</button>
                <button type="submit" class="btn btn-success">Update</button>
              </div>
            </form>
          </div>

        </div>
      </div>
    </div>
  </section>
</div>
@endsection
